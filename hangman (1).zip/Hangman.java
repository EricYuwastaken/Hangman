package hangman;
import java.util.Random ;
import java.lang.Math;
import java.util.* ;
import java.io.*;

public class Hangman { //if you want to test stuff do it in your own ide
    
    //String Method 
    public static String checkStr(String str, String ltr, String current){ 
      //str is actual word, ltr is the letter input, current is the displayed str
        if(ltr.length()==str.length()){ //for if user guesses a word
            if(ltr.equals(str)){
              return str;  
            }
            return current;               
        }
        String out = ""; //edited word for current what us specif it already does 
        //for if user guesses a letter
        System.out.println(current);
        for (int i = 0; i < str.length(); i++) {
            if (Character.toString(str.charAt(i)).equals(ltr)) {
                out+=ltr;
            }
            else{
                out+=current.charAt(i);
            }
        }
        return out;
    }
    public static void printWord(String word){
        System.out.print("Word: ");
        for (int i = 0; i < word.length(); i++) {
            System.out.print(word.charAt(i)+" ");
        }
        System.out.print("\n");
    }
    public static void main(String[] args) {
        long be=System.currentTimeMillis();
        
        
        wrong_answers object = new wrong_answers();
        
        
        
        //if string is incorrect use object.incorrect, total 5 lives
        //------------------------------------------------------
  

// --------------------------------word bank starts here----------
        Random rand=new Random();
        int b = rand.nextInt(27);

        String word = "";

        Scanner scan = new Scanner(System.in);
String[] p={"statement","variable","hangman","error","interface","string","method","static","java","function","linear","sorting","coding","public","static","void"
,"file","import","package","double","long","winner","loser","minecart","null","minecraft","exeption"
};
word=p[b];
        
        String alphabet = "abcdefghijklmnopqrstuvwxyz";
        boolean[] lettersGuessed = new boolean[26]; /* if the letter is already guessed 
        switch the index of that letter to true*/
        String guess = ""; //what word/letter the user guesses
        String current = ""; //empty word the user sees
        for (int i = 0; i < word.length(); i++) { 
            current+="_";
        }
        while(true){
            object.print();
            System.out.println("letters guessed: ");
            for (int i = 0; i < 26; i ++) {
                if (lettersGuessed[i]) {
                    System.out.print(alphabet.charAt(i) + " ");
                }
            }
            System.out.println();
            if (current.equals(word)) {
              long ce=System.currentTimeMillis();
             long timescore=(1000-(ce-be)/50);
              
              
              if(timescore<=0){
                  timescore=0;
              }
               long points=timescore+(object.getamt()*20);
               points+=100;//this is just a boost since u won
                System.out.println("the word '"+word+"' was guessed! \nscore: "+points+" points");
              
              break;
            }
            
           
            
            
            
            
            if (object.getamt() == 0) {
              int points1=0;
              long ae=System.currentTimeMillis();
              points1+=(1000-(ae-be)/50); 
                if(points1<0)points1=0;
             //---------------------------------------------------------
             //add amt of letters correct here
         for(int i=0;i<word.length();i++){
             for(int d=0;d<current.length();d++){
             if(current.charAt(d)==word.charAt(i)){
                 points1+=20;
             }
             
             }
            }
             //--------------------------------------------------------
                
              System.out.println("you ran out of lives");
              System.out.println("the word was "+word+" score:"+points1);
              break;
            } 






            printWord(current); //method at line 24 
            System.out.println("Enter a letter/word");
            guess = scan.next().toLowerCase();              
            if (guess.length()==1 && lettersGuessed[alphabet.indexOf(guess)]) {
              System.out.print("letter has already been guessed, try another one\n");
            } 
            else{
              if(current.equals(checkStr(word,guess,current))){
                object.incorrect();
              }
              current = checkStr(word,guess,current); //method at line 11
            }
            if(guess.length()==1){
              lettersGuessed[alphabet.indexOf(guess)] = true;
            }
        }

    //---------------------------------------------------
        
        
        
        //check this at the begining of each "round"
        
        
        
        
        
        
        
        
  }
    
}






class wrong_answers{
    private int amt;
    public wrong_answers(){
    amt=6;   
}
public void incorrect(){
    amt--;
    
     
     
 }   
public int getamt(){  
    return amt; 
}

public void print(){
if(amt==6){
            System.out.println("  +---+\n" +
"  |   |\n" +
"      |\n" +
"      |\n" +
"      |\n" +
"      |\n" +
"=========");
        }
        if(amt==5){
            System.out.println("  +---+\n" +
"  |   |\n" +
"  O   |\n" +
"      |\n" +
"      |\n" +
"      |\n" +
"=========");
        }
        if(amt==4){
            System.out.println("  +---+\n" +
"  |   |\n" +
"  O   |\n" +
"  |   |\n" +
"      |\n" +
"      |\n" +
"=========");
        }
        if(amt==3){
            System.out.println("  +---+\n" +
"  |   |\n" +
"  O   |\n" +
" /|   |\n" +
"      |\n" +
"      |\n" +
"=========");
        }
        if(amt==2){
            System.out.println(" +---+\n" +
"  |   |\n" +
"  O   |\n" +
" /|\\  |\n" +
"      |\n" +
"      |\n" +
"=========");
        }
        if(amt==1){
            System.out.println("  +---+\n" +
"  |   |\n" +
"  O   |\n" +
" /|\\  |\n" +
" /    |\n" +
"      |\n" +
"=========");
        }
        if(amt==0){
            System.out.println("  +---+\n" +
"  |   |\n" +
"  O   |\n" +
" /|\\  |\n" +
" / \\  |\n" +
"      |\n" +
"=========");
            System.out.println("gameover");
            // end game here
        }
  
}
//class end 
}